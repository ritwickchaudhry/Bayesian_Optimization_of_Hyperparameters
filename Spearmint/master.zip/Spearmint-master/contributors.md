Contributors
------------
We have verified that the following individuals have have submitted 
Contributor License Agreements.

[ivoanastacio](https://github.com/HIPS/Spearmint/pull/4)  
[kyunghyuncho](https://github.com/HIPS/Spearmint/pull/5)  
Peter Sadowski (psadowsk@uci.edu)  
Jacob Stevenson [js850](https://github.com/HIPS/Spearmint/pull/7)  
[lzamparo](https://github.com/HIPS/Spearmint/pull/9)  
[liori](https://github.com/HIPS/Spearmint/pull/13)  
[JesseLivezey](https://github.com/HIPS/Spearmint/pull/16)  
[ajschumacher](https://github.com/HIPS/Spearmint/pull/40)  
[danielhernandezlobato](https://github.com/HIPS/Spearmint/issues/53)
